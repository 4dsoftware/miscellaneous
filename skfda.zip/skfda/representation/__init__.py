from . import basis
from . import extrapolation
from . import grid
from . import interpolation
#from ._evaluation_trasformer import EvaluationTransformer
from ._functional_data import FData
from .basis import FDataBasis
from .grid import FDataGrid
