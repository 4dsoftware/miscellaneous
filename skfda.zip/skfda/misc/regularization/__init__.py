from ._regularization import (
    L2Regularization,
    TikhonovRegularization,
    compute_penalty_matrix,
)
